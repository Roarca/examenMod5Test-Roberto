const v_edad=require('./veirificarEdad');

describe('testeo de muchas sumas',()=>{
	expect(v_edad(-1)).toThrow(Error);
	
	test('Testeo de la verificacion 2',()=>{
		expect(v_edad(-1)).toBe('error');
	});
	test('Testeo de la verificacion 3',()=>{
	expect(v_edad(0)).toBe(false);
	});
	test('Testeo de la verificacion 4',()=>{
		expect(v_edad(1)).toBe(false);
	});
	test('Testeo de la verificacion 5',()=>{
		expect(v_edad(17)).toBe(false);
	});
	test('Testeo de la verificacion 6',()=>{
		expect(v_edad(18)).toBe(true);
	});
	test('Testeo de la verificacion 7',()=>{
		expect(v_edad(40)).toBe(true);
	});
	test('Testeo de la verificacion 8',()=>{
		expect(v_edad(41)).toBe(false);
	});
	test('Testeo de la verificacion 9',()=>{
		expect(v_edad(91)).toBe(false);
	});
});