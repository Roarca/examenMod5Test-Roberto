function verificarEdad(int edad_a_comprobar) {
        if(edad_a_comprobar<0){throw new Error("Es chiquito");}
        if(edad_a_comprobar<18){return false;}
        if(edad_a_comprobar<41){return true;}
        return false;
}
module.exports=verificarEdad;