beforeAll(()=>console.log("beforeAll"));
afterAll(()=>console.log("afterAll"));
beforeEach(()=>console.log("Delante cada test"));
afterEach(()=>console.log("afterEach"));
test("test prueba 1",()=>{console.log("Este es el test 1")});
test("test prueba 2",()=>{console.log("Este es el test 2")});