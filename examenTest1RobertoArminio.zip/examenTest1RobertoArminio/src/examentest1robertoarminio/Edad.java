package examentest1robertoarminio;



public class Edad {

    public Edad() {
    }
    
    public boolean comprobarEdad(int edad_a_comprobar) throws ExcepcionEdad{
        if(edad_a_comprobar<0){throw new ExcepcionEdad("Es chiquito");}
        if(edad_a_comprobar<18){return false;}
        if(edad_a_comprobar<41){return true;}
        return false;
    }
    
 
}
