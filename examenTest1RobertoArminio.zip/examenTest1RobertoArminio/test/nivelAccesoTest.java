/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import examentest1robertoarminio.*;
import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
/**
 *
 * @author Pc
 */
@RunWith(value=Parameterized.class)
public class nivelAccesoTest {
    private boolean ap1,ap2,ap3;
    private int esperado;
    private nivelAcceso na;

    public nivelAccesoTest(boolean ap1, boolean ap2, boolean ap3, int esperado) {
        this.ap1 = ap1;
        this.ap2 = ap2;
        this.ap3 = ap3;
        this.esperado = esperado;
    }
    
 
    
    @Before
    public void before(){
       this.na = new nivelAcceso();
    }
    
    @Parameterized.Parameters
    public static ArrayList<Object[]>getData(){
     ArrayList<Object[]> datos=new ArrayList<>();
     
        datos.add(new Object[]{true,false,false,3});
        datos.add(new Object[]{false,false,false,3});
        datos.add(new Object[]{false,true,false,3});
        datos.add(new Object[]{true,true,true,1});
        datos.add(new Object[]{true,true,false,1});
        datos.add(new Object[]{true,false,true,2});
        datos.add(new Object[]{false,true,true,2});
        datos.add(new Object[]{false,false,true,2});
        return datos;
    }
    @Test
    public void testSuma(){
        assertEquals(esperado,this.na.nivelAcceso(ap1, ap2, ap3));
    }
    
}
