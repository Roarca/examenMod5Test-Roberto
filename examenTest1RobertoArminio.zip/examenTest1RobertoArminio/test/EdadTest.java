/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import examentest1robertoarminio.*;
import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

/**
 *
 * @author Pc
 */
//@RunWith(value=Parameterized.class)
public class EdadTest {
       // private int x,esperado;
        private Edad e_edad;
        
        
    public EdadTest() {
       // this.x=x;
        // this.esperado=esperado;
    }
    @Before
    public void before(){
        e_edad=new Edad();
    }

   @Test(expected=ExcepcionEdad.class)
    public void comprobarEdades() throws ExcepcionEdad{
        e_edad.comprobarEdad(-1);
    }
    
    @Test
    public void edadpositiva() throws ExcepcionEdad{
        assertFalse(e_edad.comprobarEdad(2));
        assertFalse(e_edad.comprobarEdad(17));
        assertTrue(e_edad.comprobarEdad(18));
        assertTrue(e_edad.comprobarEdad(33));
        assertTrue(e_edad.comprobarEdad(40));
        assertFalse(e_edad.comprobarEdad(41));
        assertFalse(e_edad.comprobarEdad(50));

    }
}
